
function Update () {
	var prefix = "Blocks: ";
	var suffix = "";

	//guiText.text = prefix + Spawner.totalblocks + suffix;
	
	
	
}