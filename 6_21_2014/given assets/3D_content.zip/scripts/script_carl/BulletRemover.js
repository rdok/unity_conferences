function Update () {
	
	Destroy(gameObject,5);
	
}