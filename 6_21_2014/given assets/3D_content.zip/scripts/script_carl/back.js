

function OnGUI()
{

			
if (GUI.Button (Rect (23,180, 100, 30), "back"))

		{	
		Application.LoadLevel("start_game");
		}
		
}







	
