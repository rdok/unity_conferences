

function OnGUI()
{

			
if (GUI.Button (Rect ((Screen.width * 0.5) - 50 , 300, 100, 30), "Start Game"))

		{	
		Application.LoadLevel("island");
		}
		
}







	
