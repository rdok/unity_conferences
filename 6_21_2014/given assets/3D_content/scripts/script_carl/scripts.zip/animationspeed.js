
function Start () {

animation["back"].speed = 0.3;

}