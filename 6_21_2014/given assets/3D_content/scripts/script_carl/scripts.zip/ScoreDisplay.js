
function Update () {
	var prefix = "Skeletons: ";
	var suffix = " /10";

	

	guiText.text = prefix + BulletHit.score + suffix;
	
}